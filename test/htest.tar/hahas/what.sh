#!/bin/bash


echo "i am kernelhuang" > /tmp/hahas

echo "i am fdsfsdf"
